﻿namespace DisneyDown.Console.Dash
{
    internal class Program
    {
        private static void Main(string[] args)
        {
        }
    }
}