﻿namespace DisneyDown.Console.Dash.Common.Protection
{
    public static class ProtectionId
    {
    }
}