﻿namespace DisneyDown.Common.Globals
{
    public static class Verification
    {
        public static string MainContent { get; } = @"-MAIN/";
        public static string DubCard { get; } = @"DUB_CARD";
        public static string BumperIntro { get; } = @"-BUMPER/";
    }
}