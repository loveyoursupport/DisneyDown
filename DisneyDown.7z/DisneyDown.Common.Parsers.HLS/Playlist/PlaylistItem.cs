namespace DisneyDown.Common.Parsers.HLS.Playlist
{
    public class PlaylistItem
    {
        //This is just an inheritable base class; it does not have any purpose.
        //Please cast to the other inherited classes in order to achieve any functionality.
    }
}